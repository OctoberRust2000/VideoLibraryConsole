NReco.VideoInfo (FFProbe wrapper)
---------------------------------
Visit http://www.nrecosite.com/video_info_net.aspx for the latest information (change log, examples etc)
API documentation: http://www.nrecosite.com/doc/NReco.VideoInfo/